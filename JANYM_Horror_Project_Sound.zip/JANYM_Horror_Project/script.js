(() => {
  const intro = document.getElementById('intro');
  const scare = document.getElementById('jumpscare');
  const virus = document.getElementById('virus');
  const button = document.getElementById('dontPress');
  const exit = document.getElementById('exit');
  const bar = document.getElementById('progressBar');
  const status = document.getElementById('status');

  let started = false;
  let timers = [];
  const scareSound = new Audio('jumpscare.wav');
  scareSound.preload = 'auto';
  scareSound.volume = 0.9;

  function later(fn, ms) {
    timers.push(setTimeout(fn, ms));
  }

  function startSequence() {
    if (started) return;
    started = true;
    intro.classList.add('hidden');
    scare.classList.remove('hidden');
    scare.setAttribute('aria-hidden', 'false');
    // Play the original sound effect. If autoplay is blocked, the visual demo still works.
    scareSound.currentTime = 0;
    scareSound.play().catch(() => { status.textContent = 'Нажмите кнопку, чтобы разрешить звук браузера.'; });

    // Only browser effects; no files or system settings are touched.
    later(() => {
      scare.classList.add('hidden');
      scare.setAttribute('aria-hidden', 'true');
      virus.classList.remove('hidden');
      virus.setAttribute('aria-hidden', 'false');
      document.body.style.background = '#050000';
      let progress = 0;
      const interval = setInterval(() => {
        progress = Math.min(100, progress + 4);
        bar.style.width = progress + '%';
        status.textContent = progress < 100
          ? `СИМУЛЯЦИЯ УГРОЗЫ: ${progress}% — ДЕМО, ФАЙЛЫ НЕ ЗАТРОНУТЫ`
          : 'РОЗЫГРЫШ ЗАВЕРШЁН. КОМПЬЮТЕР НЕ ЗАРАЖЁН.';
        if (progress >= 100) clearInterval(interval);
      }, 180);
      timers.push(interval);
    }, 1800);
  }

  // If the button is not pressed for 5 seconds, the scare starts.
  const autoStart = setTimeout(startSequence, 5000);
  button.addEventListener('click', () => {
    clearTimeout(autoStart);
    startSequence();
  });

  function stopDemo() {
    timers.forEach(id => { clearTimeout(id); clearInterval(id); });
    scareSound.pause();
    scareSound.currentTime = 0;
    clearTimeout(autoStart);
    virus.classList.add('hidden');
    scare.classList.add('hidden');
    intro.classList.remove('hidden');
    scare.setAttribute('aria-hidden', 'true');
    virus.setAttribute('aria-hidden', 'true');
    document.body.style.background = '#050505';
    bar.style.width = '0%';
    status.textContent = 'ДЕМО ОСТАНОВЛЕНО.';
    started = false;
  }

  exit.addEventListener('click', stopDemo);
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') stopDemo();
  });
})();